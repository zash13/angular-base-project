import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Component, InjectionToken, NgModule, Inject } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCardModule } from '@angular/material/card';
import * as i1$1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatBadgeModule } from '@angular/material/badge';
import { MatDividerModule } from '@angular/material/divider';
import * as i2 from '@angular/cdk/scrolling';
import { ScrollingModule } from '@angular/cdk/scrolling';

class HeaderComponent {
    config = {};
    logo = { text: 'Pro Sidebar', url: '/', icon: 'menu' };
    toggleSidebar = new EventEmitter();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: HeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.3", type: HeaderComponent, isStandalone: true, selector: "lib-sidebar-header", inputs: { config: "config", logo: "logo" }, outputs: { toggleSidebar: "toggleSidebar" }, ngImport: i0, template: "<header\n  class=\"sidebar-header p-4 border-b border-gray-800 flex items-center justify-between min-h-16\"\n>\n  <div class=\"header-content flex items-center flex-1\" [class.collapsed]=\"config?.collapsed\">\n    @if (logo) {\n      <div class=\"logo-section flex items-center\">\n        @if ((logo.matIcon || logo.icon) && !config?.collapsed) {\n          <span class=\"logo-icon material-icons text-xl mr-3\">\n            {{ logo.matIcon || logo.icon }}\n          </span>\n        }\n\n        @if (logo.image && !config?.collapsed) {\n          <img [src]=\"logo.image\" [alt]=\"logo.text\" class=\"logo-image h-8 w-8 mr-3\" />\n        }\n\n        @if (!config?.collapsed) {\n          <div class=\"logo-text\">\n            @if (logo.url) {\n              <a [href]=\"logo.url\" class=\"logo-link no-underline\">\n                <h2 class=\"logo-title text-lg font-semibold text-white\">\n                  {{ logo.text || 'Pro Sidebar' }}\n                </h2>\n              </a>\n            } @else {\n              <h2 class=\"logo-title text-lg font-semibold text-white\">\n                {{ logo.text || 'Pro Sidebar' }}\n              </h2>\n            }\n          </div>\n        }\n      </div>\n    }\n  </div>\n\n  <!-- Toggle Button -->\n  <button\n    type=\"button\"\n    class=\"toggle-button p-2 rounded-full hover:bg-gray-800 transition-colors\"\n    (click)=\"toggleSidebar.emit()\"\n    [title]=\"config?.collapsed ? 'Expand sidebar' : 'Collapse sidebar'\"\n  >\n    <span class=\"material-icons text-gray-400\">\n      {{ config?.collapsed ? 'chevron_right' : 'chevron_left' }}\n    </span>\n  </button>\n</header>\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatRippleModule }, { kind: "ngmodule", type: MatTooltipModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: HeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-sidebar-header', standalone: true, imports: [CommonModule, MatIconModule, MatButtonModule, MatRippleModule, MatTooltipModule], template: "<header\n  class=\"sidebar-header p-4 border-b border-gray-800 flex items-center justify-between min-h-16\"\n>\n  <div class=\"header-content flex items-center flex-1\" [class.collapsed]=\"config?.collapsed\">\n    @if (logo) {\n      <div class=\"logo-section flex items-center\">\n        @if ((logo.matIcon || logo.icon) && !config?.collapsed) {\n          <span class=\"logo-icon material-icons text-xl mr-3\">\n            {{ logo.matIcon || logo.icon }}\n          </span>\n        }\n\n        @if (logo.image && !config?.collapsed) {\n          <img [src]=\"logo.image\" [alt]=\"logo.text\" class=\"logo-image h-8 w-8 mr-3\" />\n        }\n\n        @if (!config?.collapsed) {\n          <div class=\"logo-text\">\n            @if (logo.url) {\n              <a [href]=\"logo.url\" class=\"logo-link no-underline\">\n                <h2 class=\"logo-title text-lg font-semibold text-white\">\n                  {{ logo.text || 'Pro Sidebar' }}\n                </h2>\n              </a>\n            } @else {\n              <h2 class=\"logo-title text-lg font-semibold text-white\">\n                {{ logo.text || 'Pro Sidebar' }}\n              </h2>\n            }\n          </div>\n        }\n      </div>\n    }\n  </div>\n\n  <!-- Toggle Button -->\n  <button\n    type=\"button\"\n    class=\"toggle-button p-2 rounded-full hover:bg-gray-800 transition-colors\"\n    (click)=\"toggleSidebar.emit()\"\n    [title]=\"config?.collapsed ? 'Expand sidebar' : 'Collapse sidebar'\"\n  >\n    <span class=\"material-icons text-gray-400\">\n      {{ config?.collapsed ? 'chevron_right' : 'chevron_left' }}\n    </span>\n  </button>\n</header>\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"] }]
        }], propDecorators: { config: [{
                type: Input
            }], logo: [{
                type: Input
            }], toggleSidebar: [{
                type: Output
            }] } });

class ProfileComponent {
    config = {};
    user = {
        name: 'John Doe',
        role: 'Administrator',
        status: 'online',
        avatar: 'assets/images/avatar.png',
        email: 'john.doe@example.com',
    };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: ProfileComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.3", type: ProfileComponent, isStandalone: true, selector: "lib-sidebar-profile", inputs: { config: "config", user: "user" }, ngImport: i0, template: "@if (!config.collapsed) {\n  <div class=\"sidebar-profile m-4 p-4 bg-gray-800 rounded-lg border-0 text-gray-400\">\n    <div class=\"user-profile-content flex items-center gap-4\">\n      <div class=\"user-avatar w-15 h-15 rounded-full overflow-hidden border-2 border-gray-700\">\n        <img\n          [src]=\"user?.avatar\"\n          [alt]=\"user?.name\"\n          class=\"avatar-img w-full h-full object-cover\"\n        />\n      </div>\n      <div class=\"user-info flex-1\">\n        <h4 class=\"user-name text-base font-medium text-white mb-1\">{{ user?.name }}</h4>\n        <span class=\"user-role text-sm opacity-80\">{{ user?.role }}</span>\n        <div class=\"user-status flex items-center gap-2 mt-1\">\n          <span\n            class=\"status-indicator w-2 h-2 rounded-full\"\n            [ngClass]=\"{\n              'bg-green-500': user?.status?.toLowerCase() === 'online',\n              'bg-red-500': user?.status?.toLowerCase() === 'offline',\n              'bg-yellow-500': user?.status?.toLowerCase() === 'away',\n            }\"\n          ></span>\n          <span class=\"status-text text-xs capitalize\">{{ user?.status }}</span>\n        </div>\n      </div>\n    </div>\n  </div>\n}\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatCardModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: ProfileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-sidebar-profile', standalone: true, imports: [CommonModule, MatCardModule], template: "@if (!config.collapsed) {\n  <div class=\"sidebar-profile m-4 p-4 bg-gray-800 rounded-lg border-0 text-gray-400\">\n    <div class=\"user-profile-content flex items-center gap-4\">\n      <div class=\"user-avatar w-15 h-15 rounded-full overflow-hidden border-2 border-gray-700\">\n        <img\n          [src]=\"user?.avatar\"\n          [alt]=\"user?.name\"\n          class=\"avatar-img w-full h-full object-cover\"\n        />\n      </div>\n      <div class=\"user-info flex-1\">\n        <h4 class=\"user-name text-base font-medium text-white mb-1\">{{ user?.name }}</h4>\n        <span class=\"user-role text-sm opacity-80\">{{ user?.role }}</span>\n        <div class=\"user-status flex items-center gap-2 mt-1\">\n          <span\n            class=\"status-indicator w-2 h-2 rounded-full\"\n            [ngClass]=\"{\n              'bg-green-500': user?.status?.toLowerCase() === 'online',\n              'bg-red-500': user?.status?.toLowerCase() === 'offline',\n              'bg-yellow-500': user?.status?.toLowerCase() === 'away',\n            }\"\n          ></span>\n          <span class=\"status-text text-xs capitalize\">{{ user?.status }}</span>\n        </div>\n      </div>\n    </div>\n  </div>\n}\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"] }]
        }], propDecorators: { config: [{
                type: Input
            }], user: [{
                type: Input
            }] } });

class SearchComponent {
    config = {};
    searchText = '';
    searchChanged = new EventEmitter();
    onSearch(value) {
        this.searchText = value;
        this.searchChanged.emit(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: SearchComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.3", type: SearchComponent, isStandalone: true, selector: "lib-sidebar-search", inputs: { config: "config", searchText: "searchText" }, outputs: { searchChanged: "searchChanged" }, ngImport: i0, template: "@if (!config.collapsed) {\n  <div class=\"sidebar-search p-4\">\n    <div class=\"search-field relative\">\n      <input\n        type=\"text\"\n        [(ngModel)]=\"searchText\"\n        (ngModelChange)=\"onSearch($event)\"\n        placeholder=\"Search...\"\n        class=\"w-full px-4 py-2 pl-10 bg-gray-800 border border-gray-700 rounded-lg text-gray-300 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent\"\n      />\n      <span class=\"material-icons absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500\">\n        search\n      </span>\n    </div>\n  </div>\n}\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatButtonModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: SearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-sidebar-search', standalone: true, imports: [
                        CommonModule,
                        FormsModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatButtonModule,
                    ], template: "@if (!config.collapsed) {\n  <div class=\"sidebar-search p-4\">\n    <div class=\"search-field relative\">\n      <input\n        type=\"text\"\n        [(ngModel)]=\"searchText\"\n        (ngModelChange)=\"onSearch($event)\"\n        placeholder=\"Search...\"\n        class=\"w-full px-4 py-2 pl-10 bg-gray-800 border border-gray-700 rounded-lg text-gray-300 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent\"\n      />\n      <span class=\"material-icons absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500\">\n        search\n      </span>\n    </div>\n  </div>\n}\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"] }]
        }], propDecorators: { config: [{
                type: Input
            }], searchText: [{
                type: Input
            }], searchChanged: [{
                type: Output
            }] } });

class MenuComponent {
    menus = [];
    config = {};
    menuItemClicked = new EventEmitter();
    expandedMenuIds = new Set();
    ngOnInit() {
        // Initialize expanded menus
        this.menus.forEach((menu) => {
            if (menu.active && menu.type === 'dropdown') {
                this.expandedMenuIds.add(menu.id);
            }
        });
    }
    isAnySubmenuActive(menu) {
        if (!menu.submenus)
            return false;
        return menu.submenus.some((submenu) => submenu.active || this.isAnySubmenuActive(submenu));
    }
    toggleMenu(menu) {
        if (menu.type === 'dropdown') {
            if (this.expandedMenuIds.has(menu.id)) {
                this.expandedMenuIds.delete(menu.id);
            }
            else {
                this.expandedMenuIds.add(menu.id);
            }
            menu.active = !menu.active;
        }
        if (menu.type === 'link') {
            this.menuItemClicked.emit(menu);
        }
    }
    badgeClass(type) {
        return {
            'bg-red-500/20 text-red-400': type === 'badge-danger',
            'bg-green-500/20 text-green-400': type === 'badge-success',
            'bg-yellow-500/20 text-yellow-400': type === 'badge-warning',
        };
    }
    isMenuExpanded(menu) {
        return menu.type === 'dropdown' ? this.expandedMenuIds.has(menu.id) : false;
    }
    trackByMenuItemId(index, item) {
        return item.id;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: MenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.3", type: MenuComponent, isStandalone: true, selector: "lib-sidebar-menu", inputs: { menus: "menus", config: "config" }, outputs: { menuItemClicked: "menuItemClicked" }, ngImport: i0, template: "<ul class=\"flex flex-col gap-2 p-4 bg-slate-900 text-white\">\n  <li class=\"hover:bg-slate-700 px-3 py-2 rounded bg-emerald-300\">Dashboard</li>\n  <li class=\"hover:bg-slate-700 px-3 py-2 rounded\">Settings</li>\n</ul>\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatListModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatExpansionModule }, { kind: "ngmodule", type: MatChipsModule }, { kind: "ngmodule", type: MatRippleModule }, { kind: "ngmodule", type: MatTooltipModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: MenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-sidebar-menu', standalone: true, imports: [
                        CommonModule,
                        MatListModule,
                        MatIconModule,
                        MatExpansionModule,
                        MatChipsModule,
                        MatRippleModule,
                        MatTooltipModule,
                    ], template: "<ul class=\"flex flex-col gap-2 p-4 bg-slate-900 text-white\">\n  <li class=\"hover:bg-slate-700 px-3 py-2 rounded bg-emerald-300\">Dashboard</li>\n  <li class=\"hover:bg-slate-700 px-3 py-2 rounded\">Settings</li>\n</ul>\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"] }]
        }], propDecorators: { menus: [{
                type: Input
            }], config: [{
                type: Input
            }], menuItemClicked: [{
                type: Output
            }] } });

class FooterComponent {
    notifications = [];
    messages = [];
    unreadNotificationsCount = 0;
    unreadMessagesCount = 0;
    notificationClicked = new EventEmitter();
    messageClicked = new EventEmitter();
    logoutClicked = new EventEmitter();
    onNotificationClick(notification) {
        this.notificationClicked.emit(notification);
    }
    onMessageClick(message) {
        this.messageClicked.emit(message);
    }
    onLogout() {
        this.logoutClicked.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: FooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.3", type: FooterComponent, isStandalone: true, selector: "lib-sidebar-footer", inputs: { notifications: "notifications", messages: "messages", unreadNotificationsCount: "unreadNotificationsCount", unreadMessagesCount: "unreadMessagesCount" }, outputs: { notificationClicked: "notificationClicked", messageClicked: "messageClicked", logoutClicked: "logoutClicked" }, ngImport: i0, template: "<div class=\"sidebar-footer flex border-t border-gray-800 bg-gray-850 min-h-14\">\n  <!-- Notifications -->\n  <div class=\"footer-item flex-1 relative flex items-center justify-center\">\n    <button\n      type=\"button\"\n      class=\"footer-btn p-3 w-full h-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors relative\"\n    >\n      <span class=\"material-icons\">notifications</span>\n      @if (unreadNotificationsCount > 0) {\n        <span\n          class=\"absolute top-2 right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center\"\n        >\n          {{ unreadNotificationsCount }}\n        </span>\n      }\n    </button>\n\n    <!-- Notifications Dropdown -->\n    <div\n      class=\"dropdown-menu absolute bottom-full left-0 mb-2 w-72 bg-white rounded-lg shadow-xl z-50 hidden group-hover:block\"\n    >\n      <div class=\"dropdown-header flex items-center gap-3 p-4 font-medium text-gray-800 border-b\">\n        <span class=\"material-icons text-gray-600\">notifications</span>\n        <span>Notifications</span>\n      </div>\n\n      <div class=\"notification-items max-h-72 overflow-y-auto\">\n        @for (notification of notifications; track notification.id || $index) {\n          <div\n            class=\"notification-item flex items-center gap-3 p-3 hover:bg-gray-100 cursor-pointer\"\n            (click)=\"onNotificationClick(notification)\"\n          >\n            <div\n              class=\"notification-icon flex items-center justify-center w-9 h-9 rounded-full bg-gray-100\"\n              [ngClass]=\"{\n                'text-green-500': notification.iconColor === 'text-success',\n                'text-blue-500': notification.iconColor === 'text-info',\n                'text-yellow-500': notification.iconColor === 'text-warning',\n              }\"\n            >\n              <span class=\"material-icons text-lg\">\n                {{ notification.matIcon || notification.icon }}\n              </span>\n            </div>\n            <div class=\"notification-content flex-1\">\n              <p class=\"notification-text text-sm text-gray-700 line-clamp-2 mb-1\">\n                {{ notification.message }}\n              </p>\n              <small class=\"notification-time text-xs text-gray-500\">\n                {{ notification.time }}\n              </small>\n            </div>\n          </div>\n        }\n      </div>\n\n      <div class=\"border-t\">\n        <button class=\"w-full flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 text-sm\">\n          <span class=\"material-icons text-lg\">visibility</span>\n          <span>View all notifications</span>\n        </button>\n      </div>\n    </div>\n  </div>\n\n  <!-- Messages -->\n  <div class=\"footer-item flex-1 relative flex items-center justify-center\">\n    <button\n      type=\"button\"\n      class=\"footer-btn p-3 w-full h-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors relative\"\n    >\n      <span class=\"material-icons\">mail</span>\n      @if (unreadMessagesCount > 0) {\n        <span\n          class=\"absolute top-2 right-2 bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center\"\n        >\n          {{ unreadMessagesCount }}\n        </span>\n      }\n    </button>\n\n    <!-- Messages Dropdown -->\n    <div\n      class=\"dropdown-menu absolute bottom-full left-0 mb-2 w-72 bg-white rounded-lg shadow-xl z-50 hidden group-hover:block\"\n    >\n      <div class=\"dropdown-header flex items-center gap-3 p-4 font-medium text-gray-800 border-b\">\n        <span class=\"material-icons text-gray-600\">mail</span>\n        <span>Messages</span>\n      </div>\n\n      <div class=\"message-items max-h-72 overflow-y-auto\">\n        @for (message of messages; track message.id || $index) {\n          <div\n            class=\"message-item flex items-center gap-3 p-3 hover:bg-gray-100 cursor-pointer\"\n            (click)=\"onMessageClick(message)\"\n          >\n            <img\n              [src]=\"message.avatar\"\n              [alt]=\"message.sender\"\n              class=\"message-avatar w-10 h-10 rounded-full object-cover\"\n            />\n            <div class=\"message-content flex-1\">\n              <strong class=\"message-sender block text-sm font-medium text-gray-800 mb-1\">\n                {{ message.sender }}\n              </strong>\n              <p class=\"message-text text-xs text-gray-600 truncate mb-1\">\n                {{ message.message }}\n              </p>\n              <small class=\"message-time text-xs text-gray-500\">\n                {{ message.time }}\n              </small>\n            </div>\n          </div>\n        }\n      </div>\n\n      <div class=\"border-t\">\n        <button class=\"w-full flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 text-sm\">\n          <span class=\"material-icons text-lg\">inbox</span>\n          <span>View all messages</span>\n        </button>\n      </div>\n    </div>\n  </div>\n\n  <!-- Settings -->\n  <div class=\"footer-item flex-1 relative flex items-center justify-center\">\n    <button\n      type=\"button\"\n      class=\"footer-btn p-3 w-full h-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors\"\n    >\n      <span class=\"material-icons\">settings</span>\n    </button>\n\n    <!-- Settings Dropdown -->\n    <div\n      class=\"dropdown-menu absolute bottom-full left-0 mb-2 w-48 bg-white rounded-lg shadow-xl z-50 hidden group-hover:block\"\n    >\n      <button\n        class=\"dropdown-item flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 w-full text-sm\"\n      >\n        <span class=\"material-icons text-lg\">person</span>\n        <span>My profile</span>\n      </button>\n      <button\n        class=\"dropdown-item flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 w-full text-sm\"\n      >\n        <span class=\"material-icons text-lg\">help</span>\n        <span>Help</span>\n      </button>\n      <button\n        class=\"dropdown-item flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 w-full text-sm\"\n      >\n        <span class=\"material-icons text-lg\">settings</span>\n        <span>Settings</span>\n      </button>\n    </div>\n  </div>\n\n  <!-- Logout -->\n  <div class=\"footer-item flex-1 flex items-center justify-center\">\n    <button\n      type=\"button\"\n      class=\"footer-btn p-3 w-full h-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors\"\n      (click)=\"onLogout()\"\n      title=\"Logout\"\n    >\n      <span class=\"material-icons\">power_settings_new</span>\n    </button>\n  </div>\n</div>\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatMenuModule }, { kind: "ngmodule", type: MatBadgeModule }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: MatTooltipModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: FooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-sidebar-footer', standalone: true, imports: [
                        CommonModule,
                        MatButtonModule,
                        MatIconModule,
                        MatMenuModule,
                        MatBadgeModule,
                        MatDividerModule,
                        MatTooltipModule,
                    ], template: "<div class=\"sidebar-footer flex border-t border-gray-800 bg-gray-850 min-h-14\">\n  <!-- Notifications -->\n  <div class=\"footer-item flex-1 relative flex items-center justify-center\">\n    <button\n      type=\"button\"\n      class=\"footer-btn p-3 w-full h-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors relative\"\n    >\n      <span class=\"material-icons\">notifications</span>\n      @if (unreadNotificationsCount > 0) {\n        <span\n          class=\"absolute top-2 right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center\"\n        >\n          {{ unreadNotificationsCount }}\n        </span>\n      }\n    </button>\n\n    <!-- Notifications Dropdown -->\n    <div\n      class=\"dropdown-menu absolute bottom-full left-0 mb-2 w-72 bg-white rounded-lg shadow-xl z-50 hidden group-hover:block\"\n    >\n      <div class=\"dropdown-header flex items-center gap-3 p-4 font-medium text-gray-800 border-b\">\n        <span class=\"material-icons text-gray-600\">notifications</span>\n        <span>Notifications</span>\n      </div>\n\n      <div class=\"notification-items max-h-72 overflow-y-auto\">\n        @for (notification of notifications; track notification.id || $index) {\n          <div\n            class=\"notification-item flex items-center gap-3 p-3 hover:bg-gray-100 cursor-pointer\"\n            (click)=\"onNotificationClick(notification)\"\n          >\n            <div\n              class=\"notification-icon flex items-center justify-center w-9 h-9 rounded-full bg-gray-100\"\n              [ngClass]=\"{\n                'text-green-500': notification.iconColor === 'text-success',\n                'text-blue-500': notification.iconColor === 'text-info',\n                'text-yellow-500': notification.iconColor === 'text-warning',\n              }\"\n            >\n              <span class=\"material-icons text-lg\">\n                {{ notification.matIcon || notification.icon }}\n              </span>\n            </div>\n            <div class=\"notification-content flex-1\">\n              <p class=\"notification-text text-sm text-gray-700 line-clamp-2 mb-1\">\n                {{ notification.message }}\n              </p>\n              <small class=\"notification-time text-xs text-gray-500\">\n                {{ notification.time }}\n              </small>\n            </div>\n          </div>\n        }\n      </div>\n\n      <div class=\"border-t\">\n        <button class=\"w-full flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 text-sm\">\n          <span class=\"material-icons text-lg\">visibility</span>\n          <span>View all notifications</span>\n        </button>\n      </div>\n    </div>\n  </div>\n\n  <!-- Messages -->\n  <div class=\"footer-item flex-1 relative flex items-center justify-center\">\n    <button\n      type=\"button\"\n      class=\"footer-btn p-3 w-full h-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors relative\"\n    >\n      <span class=\"material-icons\">mail</span>\n      @if (unreadMessagesCount > 0) {\n        <span\n          class=\"absolute top-2 right-2 bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center\"\n        >\n          {{ unreadMessagesCount }}\n        </span>\n      }\n    </button>\n\n    <!-- Messages Dropdown -->\n    <div\n      class=\"dropdown-menu absolute bottom-full left-0 mb-2 w-72 bg-white rounded-lg shadow-xl z-50 hidden group-hover:block\"\n    >\n      <div class=\"dropdown-header flex items-center gap-3 p-4 font-medium text-gray-800 border-b\">\n        <span class=\"material-icons text-gray-600\">mail</span>\n        <span>Messages</span>\n      </div>\n\n      <div class=\"message-items max-h-72 overflow-y-auto\">\n        @for (message of messages; track message.id || $index) {\n          <div\n            class=\"message-item flex items-center gap-3 p-3 hover:bg-gray-100 cursor-pointer\"\n            (click)=\"onMessageClick(message)\"\n          >\n            <img\n              [src]=\"message.avatar\"\n              [alt]=\"message.sender\"\n              class=\"message-avatar w-10 h-10 rounded-full object-cover\"\n            />\n            <div class=\"message-content flex-1\">\n              <strong class=\"message-sender block text-sm font-medium text-gray-800 mb-1\">\n                {{ message.sender }}\n              </strong>\n              <p class=\"message-text text-xs text-gray-600 truncate mb-1\">\n                {{ message.message }}\n              </p>\n              <small class=\"message-time text-xs text-gray-500\">\n                {{ message.time }}\n              </small>\n            </div>\n          </div>\n        }\n      </div>\n\n      <div class=\"border-t\">\n        <button class=\"w-full flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 text-sm\">\n          <span class=\"material-icons text-lg\">inbox</span>\n          <span>View all messages</span>\n        </button>\n      </div>\n    </div>\n  </div>\n\n  <!-- Settings -->\n  <div class=\"footer-item flex-1 relative flex items-center justify-center\">\n    <button\n      type=\"button\"\n      class=\"footer-btn p-3 w-full h-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors\"\n    >\n      <span class=\"material-icons\">settings</span>\n    </button>\n\n    <!-- Settings Dropdown -->\n    <div\n      class=\"dropdown-menu absolute bottom-full left-0 mb-2 w-48 bg-white rounded-lg shadow-xl z-50 hidden group-hover:block\"\n    >\n      <button\n        class=\"dropdown-item flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 w-full text-sm\"\n      >\n        <span class=\"material-icons text-lg\">person</span>\n        <span>My profile</span>\n      </button>\n      <button\n        class=\"dropdown-item flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 w-full text-sm\"\n      >\n        <span class=\"material-icons text-lg\">help</span>\n        <span>Help</span>\n      </button>\n      <button\n        class=\"dropdown-item flex items-center gap-3 p-3 text-gray-700 hover:bg-gray-100 w-full text-sm\"\n      >\n        <span class=\"material-icons text-lg\">settings</span>\n        <span>Settings</span>\n      </button>\n    </div>\n  </div>\n\n  <!-- Logout -->\n  <div class=\"footer-item flex-1 flex items-center justify-center\">\n    <button\n      type=\"button\"\n      class=\"footer-btn p-3 w-full h-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors\"\n      (click)=\"onLogout()\"\n      title=\"Logout\"\n    >\n      <span class=\"material-icons\">power_settings_new</span>\n    </button>\n  </div>\n</div>\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}\n"] }]
        }], propDecorators: { notifications: [{
                type: Input
            }], messages: [{
                type: Input
            }], unreadNotificationsCount: [{
                type: Input
            }], unreadMessagesCount: [{
                type: Input
            }], notificationClicked: [{
                type: Output
            }], messageClicked: [{
                type: Output
            }], logoutClicked: [{
                type: Output
            }] } });

const SIDEBAR_DATA_SOURCE = new InjectionToken('SIDEBAR_DATA_SOURCE');

class SidebarMaterialModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: SidebarMaterialModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.1.3", ngImport: i0, type: SidebarMaterialModule, imports: [CommonModule,
            MatMenuModule,
            MatIconModule,
            MatButtonModule,
            MatRippleModule,
            MatDividerModule,
            MatListModule,
            MatTooltipModule,
            MatBadgeModule,
            MatExpansionModule,
            MatChipsModule,
            ScrollingModule], exports: [MatMenuModule,
            MatIconModule,
            MatButtonModule,
            MatRippleModule,
            MatDividerModule,
            MatListModule,
            MatTooltipModule,
            MatBadgeModule,
            MatExpansionModule,
            MatChipsModule,
            ScrollingModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: SidebarMaterialModule, imports: [CommonModule,
            MatMenuModule,
            MatIconModule,
            MatButtonModule,
            MatRippleModule,
            MatDividerModule,
            MatListModule,
            MatTooltipModule,
            MatBadgeModule,
            MatExpansionModule,
            MatChipsModule,
            ScrollingModule, MatMenuModule,
            MatIconModule,
            MatButtonModule,
            MatRippleModule,
            MatDividerModule,
            MatListModule,
            MatTooltipModule,
            MatBadgeModule,
            MatExpansionModule,
            MatChipsModule,
            ScrollingModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: SidebarMaterialModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        MatMenuModule,
                        MatIconModule,
                        MatButtonModule,
                        MatRippleModule,
                        MatDividerModule,
                        MatListModule,
                        MatTooltipModule,
                        MatBadgeModule,
                        MatExpansionModule,
                        MatChipsModule,
                        ScrollingModule,
                    ],
                    exports: [
                        MatMenuModule,
                        MatIconModule,
                        MatButtonModule,
                        MatRippleModule,
                        MatDividerModule,
                        MatListModule,
                        MatTooltipModule,
                        MatBadgeModule,
                        MatExpansionModule,
                        MatChipsModule,
                        ScrollingModule,
                    ],
                }]
        }] });

class SidebarComponent {
    _dataSource;
    subscriptions = new Subscription();
    dataSource;
    menus = [];
    config = {
        width: 260,
        collapsedWidth: 80,
        collapsed: false,
        animate: true,
    };
    user;
    logo;
    showSearch = true;
    showProfile = true;
    showNotifications = true;
    showMessages = true;
    menuItemClicked = new EventEmitter();
    sidebarToggled = new EventEmitter();
    logoutClicked = new EventEmitter();
    searchChanged = new EventEmitter();
    notificationClicked = new EventEmitter();
    messageClicked = new EventEmitter();
    searchText = '';
    isMobile = false;
    notifications = [];
    messages = [];
    unreadNotificationsCount = 0;
    unreadMessagesCount = 0;
    constructor(_dataSource) {
        this._dataSource = _dataSource;
        this.dataSource = _dataSource;
    }
    // ---------------- lifecycle ----------------
    ngOnInit() {
        this.checkMobile();
        this.loadData();
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
    // ---------------- data ----------------
    loadData() {
        // menus are OPTIONAL input
        if (!this.menus.length) {
            this.subscriptions.add(this.dataSource.menus().subscribe((menus) => (this.menus = menus)));
        }
        this.subscriptions.add(this.dataSource.notifications().subscribe((n) => {
            this.notifications = n;
            this.updateUnreadCounts();
        }));
        this.subscriptions.add(this.dataSource.messages().subscribe((m) => {
            this.messages = m;
            this.updateUnreadCounts();
        }));
    }
    // ---------------- UI actions ----------------
    toggleSidebar() {
        this.config.collapsed = !this.config.collapsed;
        this.sidebarToggled.emit(this.config.collapsed);
    }
    onNotificationClick(notification) {
        this.notificationClicked.emit(notification);
        this.dataSource.markNotificationAsRead(notification.id.toString());
    }
    onMessageClick(message) {
        this.messageClicked.emit(message);
        this.dataSource.markMessageAsRead(message.id.toString());
    }
    onSearch(value) {
        this.searchChanged.emit(value);
    }
    onLogout() {
        this.logoutClicked.emit();
    }
    // ---------------- helpers ----------------
    updateUnreadCounts() {
        this.unreadNotificationsCount = this.notifications.filter((n) => !n.read).length;
        this.unreadMessagesCount = this.messages.filter((m) => !m.read).length;
    }
    checkMobile() {
        this.isMobile = window.innerWidth < 768;
        if (this.isMobile) {
            this.config.collapsed = true;
        }
    }
    get sidebarWidth() {
        return this.config.collapsed
            ? `${this.config.collapsedWidth ?? 80}px`
            : `${this.config.width ?? 260}px`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: SidebarComponent, deps: [{ token: SIDEBAR_DATA_SOURCE }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.3", type: SidebarComponent, isStandalone: true, selector: "lib-sidebar", inputs: { menus: "menus", config: "config", user: "user", logo: "logo", showSearch: "showSearch", showProfile: "showProfile", showNotifications: "showNotifications", showMessages: "showMessages" }, outputs: { menuItemClicked: "menuItemClicked", sidebarToggled: "sidebarToggled", logoutClicked: "logoutClicked", searchChanged: "searchChanged", notificationClicked: "notificationClicked", messageClicked: "messageClicked" }, ngImport: i0, template: "<head>\n  <!-- Add this line -->\n  <link href=\"https://fonts.googleapis.com/icon?family=Material+Icons\" rel=\"stylesheet\" />\n\n  <!-- Or for Material Symbols (recommended) -->\n  <link\n    rel=\"stylesheet\"\n    href=\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200\"\n  />\n</head>\n<nav\n  class=\"sidebar mat-elevation-z4\"\n  [ngClass]=\"{\n    'sidebar-collapsed': config.collapsed,\n    'sidebar-': config.position === 'left',\n    'sidebar-rtl': config.rtl,\n    'sidebar-mobile': isMobile,\n    'sidebar-with-backdrop': config.backdrop && isMobile,\n    'sidebar-bg': config.backgroundImage,\n    'light-theme': config.theme === 'light',\n  }\"\n  [style.backgroundImage]=\"config.backgroundImage ? 'url(' + config.backgroundImage + ')' : null\"\n>\n  <!-- Backdrop for mobile -->\n  @if (config.backdrop && isMobile && !config.collapsed) {\n    <div\n      class=\"sidebar-backdrop mat-app-backdrop\"\n      [style.opacity]=\"config.backdropOpacity || 0.5\"\n      (click)=\"toggleSidebar()\"\n    ></div>\n  }\n  <div class=\"sidebar-content\">\n    <cdk-virtual-scroll-viewport itemSize=\"48\" class=\"sidebar-scroll-viewport\">\n      <!-- Sidebar Header -->\n      <lib-sidebar-header\n        [config]=\"config\"\n        [logo]=\"logo\"\n        (toggleSidebar)=\"toggleSidebar()\"\n      ></lib-sidebar-header>\n\n      <!-- User Profile -->\n      @if (showProfile) {\n        <lib-sidebar-profile [config]=\"config\" [user]=\"user\"></lib-sidebar-profile>\n      }\n\n      <!-- Search -->\n      @if (showSearch) {\n        <lib-sidebar-search\n          [config]=\"config\"\n          [searchText]=\"searchText\"\n          (searchChanged)=\"onSearch($event)\"\n        ></lib-sidebar-search>\n      }\n\n      <!-- Menu -->\n    </cdk-virtual-scroll-viewport>\n  </div>\n\n  <!-- Sidebar Footer -->\n  <lib-sidebar-footer\n    [notifications]=\"notifications\"\n    [messages]=\"messages\"\n    [unreadNotificationsCount]=\"unreadNotificationsCount\"\n    [unreadMessagesCount]=\"unreadMessagesCount\"\n    (notificationClicked)=\"onNotificationClick($event)\"\n    (messageClicked)=\"onMessageClick($event)\"\n    (logoutClicked)=\"onLogout()\"\n  ></lib-sidebar-footer>\n</nav>\n\n<lib-sidebar-menu\n  [menus]=\"menus\"\n  [config]=\"config\"\n  (menuItemClicked)=\"menuItemClicked.emit($event)\"\n></lib-sidebar-menu>\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]:where(:not([hidden=until-found])){display:none}.container{width:100%}@media(min-width:640px){.container{max-width:640px}}@media(min-width:768px){.container{max-width:768px}}@media(min-width:1024px){.container{max-width:1024px}}@media(min-width:1280px){.container{max-width:1280px}}@media(min-width:1536px){.container{max-width:1536px}}.\\!visible{visibility:visible!important}.visible{visibility:visible}.invisible{visibility:hidden}.collapse{visibility:collapse}.static{position:static}.fixed{position:fixed}.absolute{position:absolute}.relative{position:relative}.sticky{position:sticky}.bottom-full{bottom:100%}.left-0{left:0}.left-3{left:.75rem}.right-2{right:.5rem}.top-1\\/2{top:50%}.top-2{top:.5rem}.z-50{z-index:50}.m-4{margin:1rem}.mb-1{margin-bottom:.25rem}.mb-2{margin-bottom:.5rem}.mr-3{margin-right:.75rem}.mt-1{margin-top:.25rem}.line-clamp-2{overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2}.block{display:block}.inline{display:inline}.flex{display:flex}.table{display:table}.grid{display:grid}.contents{display:contents}.list-item{display:list-item}.hidden{display:none}.h-10{height:2.5rem}.h-2{height:.5rem}.h-5{height:1.25rem}.h-8{height:2rem}.h-9{height:2.25rem}.h-full{height:100%}.max-h-72{max-height:18rem}.min-h-14{min-height:3.5rem}.min-h-16{min-height:4rem}.w-10{width:2.5rem}.w-2{width:.5rem}.w-48{width:12rem}.w-5{width:1.25rem}.w-72{width:18rem}.w-8{width:2rem}.w-9{width:2.25rem}.w-full{width:100%}.flex-1{flex:1 1 0%}.shrink{flex-shrink:1}.grow{flex-grow:1}.-translate-y-1\\/2{--tw-translate-y: -50%;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.transform{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.cursor-pointer{cursor:pointer}.resize{resize:both}.flex-col{flex-direction:column}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-2{gap:.5rem}.gap-3{gap:.75rem}.gap-4{gap:1rem}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rounded{border-radius:.25rem}.rounded-full{border-radius:9999px}.rounded-lg{border-radius:.5rem}.border{border-width:1px}.border-0{border-width:0px}.border-2{border-width:2px}.border-b{border-bottom-width:1px}.border-t{border-top-width:1px}.border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81 / var(--tw-border-opacity, 1))}.border-gray-800{--tw-border-opacity: 1;border-color:rgb(31 41 55 / var(--tw-border-opacity, 1))}.bg-blue-500{--tw-bg-opacity: 1;background-color:rgb(59 130 246 / var(--tw-bg-opacity, 1))}.bg-emerald-300{--tw-bg-opacity: 1;background-color:rgb(110 231 183 / var(--tw-bg-opacity, 1))}.bg-gray-100{--tw-bg-opacity: 1;background-color:rgb(243 244 246 / var(--tw-bg-opacity, 1))}.bg-gray-800{--tw-bg-opacity: 1;background-color:rgb(31 41 55 / var(--tw-bg-opacity, 1))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94 / var(--tw-bg-opacity, 1))}.bg-green-500\\/20{background-color:#22c55e33}.bg-red-500{--tw-bg-opacity: 1;background-color:rgb(239 68 68 / var(--tw-bg-opacity, 1))}.bg-red-500\\/20{background-color:#ef444433}.bg-slate-900{--tw-bg-opacity: 1;background-color:rgb(15 23 42 / var(--tw-bg-opacity, 1))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity, 1))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8 / var(--tw-bg-opacity, 1))}.bg-yellow-500\\/20{background-color:#eab30833}.object-cover{object-fit:cover}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.px-3{padding-left:.75rem;padding-right:.75rem}.px-4{padding-left:1rem;padding-right:1rem}.py-2{padding-top:.5rem;padding-bottom:.5rem}.pl-10{padding-left:2.5rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-xs{font-size:.75rem;line-height:1rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.uppercase{text-transform:uppercase}.lowercase{text-transform:lowercase}.capitalize{text-transform:capitalize}.italic{font-style:italic}.text-blue-500{--tw-text-opacity: 1;color:rgb(59 130 246 / var(--tw-text-opacity, 1))}.text-gray-300{--tw-text-opacity: 1;color:rgb(209 213 219 / var(--tw-text-opacity, 1))}.text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175 / var(--tw-text-opacity, 1))}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99 / var(--tw-text-opacity, 1))}.text-gray-700{--tw-text-opacity: 1;color:rgb(55 65 81 / var(--tw-text-opacity, 1))}.text-gray-800{--tw-text-opacity: 1;color:rgb(31 41 55 / var(--tw-text-opacity, 1))}.text-green-400{--tw-text-opacity: 1;color:rgb(74 222 128 / var(--tw-text-opacity, 1))}.text-green-500{--tw-text-opacity: 1;color:rgb(34 197 94 / var(--tw-text-opacity, 1))}.text-red-400{--tw-text-opacity: 1;color:rgb(248 113 113 / var(--tw-text-opacity, 1))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255 / var(--tw-text-opacity, 1))}.text-yellow-400{--tw-text-opacity: 1;color:rgb(250 204 21 / var(--tw-text-opacity, 1))}.text-yellow-500{--tw-text-opacity: 1;color:rgb(234 179 8 / var(--tw-text-opacity, 1))}.underline{text-decoration-line:underline}.overline{text-decoration-line:overline}.no-underline{text-decoration-line:none}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.placeholder-gray-500::placeholder{--tw-placeholder-opacity: 1;color:rgb(107 114 128 / var(--tw-placeholder-opacity, 1))}.opacity-80{opacity:.8}.shadow{--tw-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}.shadow-xl{--tw-shadow: 0 20px 25px -5px rgb(0 0 0 / .1), 0 8px 10px -6px rgb(0 0 0 / .1);--tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}.outline{outline-style:solid}.ring{--tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow, 0 0 #0000)}.blur{--tw-blur: blur(8px);filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.grayscale{--tw-grayscale: grayscale(100%);filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.invert{--tw-invert: invert(100%);filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.sepia{--tw-sepia: sepia(100%);filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.transition{transition-property:color,background-color,border-color,text-decoration-color,fill,stroke,opacity,box-shadow,transform,filter,backdrop-filter;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-colors{transition-property:color,background-color,border-color,text-decoration-color,fill,stroke;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.\\[k\\:string\\]{k:string}.hover\\:bg-gray-100:hover{--tw-bg-opacity: 1;background-color:rgb(243 244 246 / var(--tw-bg-opacity, 1))}.hover\\:bg-gray-800:hover{--tw-bg-opacity: 1;background-color:rgb(31 41 55 / var(--tw-bg-opacity, 1))}.hover\\:bg-slate-700:hover{--tw-bg-opacity: 1;background-color:rgb(51 65 85 / var(--tw-bg-opacity, 1))}.hover\\:text-white:hover{--tw-text-opacity: 1;color:rgb(255 255 255 / var(--tw-text-opacity, 1))}.focus\\:border-transparent:focus{border-color:transparent}.focus\\:outline-none:focus{outline:2px solid transparent;outline-offset:2px}.focus\\:ring-2:focus{--tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow, 0 0 #0000)}.focus\\:ring-blue-500:focus{--tw-ring-opacity: 1;--tw-ring-color: rgb(59 130 246 / var(--tw-ring-opacity, 1))}.group:hover .group-hover\\:block{display:block}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: SidebarMaterialModule }, { kind: "directive", type: i2.CdkFixedSizeVirtualScroll, selector: "cdk-virtual-scroll-viewport[itemSize]", inputs: ["itemSize", "minBufferPx", "maxBufferPx"] }, { kind: "component", type: i2.CdkVirtualScrollViewport, selector: "cdk-virtual-scroll-viewport", inputs: ["orientation", "appendOnly"], outputs: ["scrolledIndexChange"] }, { kind: "component", type: HeaderComponent, selector: "lib-sidebar-header", inputs: ["config", "logo"], outputs: ["toggleSidebar"] }, { kind: "component", type: ProfileComponent, selector: "lib-sidebar-profile", inputs: ["config", "user"] }, { kind: "component", type: SearchComponent, selector: "lib-sidebar-search", inputs: ["config", "searchText"], outputs: ["searchChanged"] }, { kind: "component", type: MenuComponent, selector: "lib-sidebar-menu", inputs: ["menus", "config"], outputs: ["menuItemClicked"] }, { kind: "component", type: FooterComponent, selector: "lib-sidebar-footer", inputs: ["notifications", "messages", "unreadNotificationsCount", "unreadMessagesCount"], outputs: ["notificationClicked", "messageClicked", "logoutClicked"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.3", ngImport: i0, type: SidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-sidebar', standalone: true, imports: [
                        CommonModule,
                        SidebarMaterialModule,
                        HeaderComponent,
                        ProfileComponent,
                        SearchComponent,
                        MenuComponent,
                        FooterComponent,
                    ], template: "<head>\n  <!-- Add this line -->\n  <link href=\"https://fonts.googleapis.com/icon?family=Material+Icons\" rel=\"stylesheet\" />\n\n  <!-- Or for Material Symbols (recommended) -->\n  <link\n    rel=\"stylesheet\"\n    href=\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200\"\n  />\n</head>\n<nav\n  class=\"sidebar mat-elevation-z4\"\n  [ngClass]=\"{\n    'sidebar-collapsed': config.collapsed,\n    'sidebar-': config.position === 'left',\n    'sidebar-rtl': config.rtl,\n    'sidebar-mobile': isMobile,\n    'sidebar-with-backdrop': config.backdrop && isMobile,\n    'sidebar-bg': config.backgroundImage,\n    'light-theme': config.theme === 'light',\n  }\"\n  [style.backgroundImage]=\"config.backgroundImage ? 'url(' + config.backgroundImage + ')' : null\"\n>\n  <!-- Backdrop for mobile -->\n  @if (config.backdrop && isMobile && !config.collapsed) {\n    <div\n      class=\"sidebar-backdrop mat-app-backdrop\"\n      [style.opacity]=\"config.backdropOpacity || 0.5\"\n      (click)=\"toggleSidebar()\"\n    ></div>\n  }\n  <div class=\"sidebar-content\">\n    <cdk-virtual-scroll-viewport itemSize=\"48\" class=\"sidebar-scroll-viewport\">\n      <!-- Sidebar Header -->\n      <lib-sidebar-header\n        [config]=\"config\"\n        [logo]=\"logo\"\n        (toggleSidebar)=\"toggleSidebar()\"\n      ></lib-sidebar-header>\n\n      <!-- User Profile -->\n      @if (showProfile) {\n        <lib-sidebar-profile [config]=\"config\" [user]=\"user\"></lib-sidebar-profile>\n      }\n\n      <!-- Search -->\n      @if (showSearch) {\n        <lib-sidebar-search\n          [config]=\"config\"\n          [searchText]=\"searchText\"\n          (searchChanged)=\"onSearch($event)\"\n        ></lib-sidebar-search>\n      }\n\n      <!-- Menu -->\n    </cdk-virtual-scroll-viewport>\n  </div>\n\n  <!-- Sidebar Footer -->\n  <lib-sidebar-footer\n    [notifications]=\"notifications\"\n    [messages]=\"messages\"\n    [unreadNotificationsCount]=\"unreadNotificationsCount\"\n    [unreadMessagesCount]=\"unreadMessagesCount\"\n    (notificationClicked)=\"onNotificationClick($event)\"\n    (messageClicked)=\"onMessageClick($event)\"\n    (logoutClicked)=\"onLogout()\"\n  ></lib-sidebar-footer>\n</nav>\n\n<lib-sidebar-menu\n  [menus]=\"menus\"\n  [config]=\"config\"\n  (menuItemClicked)=\"menuItemClicked.emit($event)\"\n></lib-sidebar-menu>\n", styles: [":host{--sidebar-width: 260px;--sidebar-collapsed-width: 80px;--sidebar-bg: #1d1d1d;--sidebar-color: #bdbdbd;--sidebar-hover-color: #ffffff;--sidebar-border-color: #2b2b2b;--sidebar-header-color: #6c7b88}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes swing{0%{transform:rotate(0)}25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}to{transform:rotate(0)}}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]:where(:not([hidden=until-found])){display:none}.container{width:100%}@media(min-width:640px){.container{max-width:640px}}@media(min-width:768px){.container{max-width:768px}}@media(min-width:1024px){.container{max-width:1024px}}@media(min-width:1280px){.container{max-width:1280px}}@media(min-width:1536px){.container{max-width:1536px}}.\\!visible{visibility:visible!important}.visible{visibility:visible}.invisible{visibility:hidden}.collapse{visibility:collapse}.static{position:static}.fixed{position:fixed}.absolute{position:absolute}.relative{position:relative}.sticky{position:sticky}.bottom-full{bottom:100%}.left-0{left:0}.left-3{left:.75rem}.right-2{right:.5rem}.top-1\\/2{top:50%}.top-2{top:.5rem}.z-50{z-index:50}.m-4{margin:1rem}.mb-1{margin-bottom:.25rem}.mb-2{margin-bottom:.5rem}.mr-3{margin-right:.75rem}.mt-1{margin-top:.25rem}.line-clamp-2{overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2}.block{display:block}.inline{display:inline}.flex{display:flex}.table{display:table}.grid{display:grid}.contents{display:contents}.list-item{display:list-item}.hidden{display:none}.h-10{height:2.5rem}.h-2{height:.5rem}.h-5{height:1.25rem}.h-8{height:2rem}.h-9{height:2.25rem}.h-full{height:100%}.max-h-72{max-height:18rem}.min-h-14{min-height:3.5rem}.min-h-16{min-height:4rem}.w-10{width:2.5rem}.w-2{width:.5rem}.w-48{width:12rem}.w-5{width:1.25rem}.w-72{width:18rem}.w-8{width:2rem}.w-9{width:2.25rem}.w-full{width:100%}.flex-1{flex:1 1 0%}.shrink{flex-shrink:1}.grow{flex-grow:1}.-translate-y-1\\/2{--tw-translate-y: -50%;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.transform{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.cursor-pointer{cursor:pointer}.resize{resize:both}.flex-col{flex-direction:column}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-2{gap:.5rem}.gap-3{gap:.75rem}.gap-4{gap:1rem}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rounded{border-radius:.25rem}.rounded-full{border-radius:9999px}.rounded-lg{border-radius:.5rem}.border{border-width:1px}.border-0{border-width:0px}.border-2{border-width:2px}.border-b{border-bottom-width:1px}.border-t{border-top-width:1px}.border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81 / var(--tw-border-opacity, 1))}.border-gray-800{--tw-border-opacity: 1;border-color:rgb(31 41 55 / var(--tw-border-opacity, 1))}.bg-blue-500{--tw-bg-opacity: 1;background-color:rgb(59 130 246 / var(--tw-bg-opacity, 1))}.bg-emerald-300{--tw-bg-opacity: 1;background-color:rgb(110 231 183 / var(--tw-bg-opacity, 1))}.bg-gray-100{--tw-bg-opacity: 1;background-color:rgb(243 244 246 / var(--tw-bg-opacity, 1))}.bg-gray-800{--tw-bg-opacity: 1;background-color:rgb(31 41 55 / var(--tw-bg-opacity, 1))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94 / var(--tw-bg-opacity, 1))}.bg-green-500\\/20{background-color:#22c55e33}.bg-red-500{--tw-bg-opacity: 1;background-color:rgb(239 68 68 / var(--tw-bg-opacity, 1))}.bg-red-500\\/20{background-color:#ef444433}.bg-slate-900{--tw-bg-opacity: 1;background-color:rgb(15 23 42 / var(--tw-bg-opacity, 1))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity, 1))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8 / var(--tw-bg-opacity, 1))}.bg-yellow-500\\/20{background-color:#eab30833}.object-cover{object-fit:cover}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.px-3{padding-left:.75rem;padding-right:.75rem}.px-4{padding-left:1rem;padding-right:1rem}.py-2{padding-top:.5rem;padding-bottom:.5rem}.pl-10{padding-left:2.5rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-xs{font-size:.75rem;line-height:1rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.uppercase{text-transform:uppercase}.lowercase{text-transform:lowercase}.capitalize{text-transform:capitalize}.italic{font-style:italic}.text-blue-500{--tw-text-opacity: 1;color:rgb(59 130 246 / var(--tw-text-opacity, 1))}.text-gray-300{--tw-text-opacity: 1;color:rgb(209 213 219 / var(--tw-text-opacity, 1))}.text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175 / var(--tw-text-opacity, 1))}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99 / var(--tw-text-opacity, 1))}.text-gray-700{--tw-text-opacity: 1;color:rgb(55 65 81 / var(--tw-text-opacity, 1))}.text-gray-800{--tw-text-opacity: 1;color:rgb(31 41 55 / var(--tw-text-opacity, 1))}.text-green-400{--tw-text-opacity: 1;color:rgb(74 222 128 / var(--tw-text-opacity, 1))}.text-green-500{--tw-text-opacity: 1;color:rgb(34 197 94 / var(--tw-text-opacity, 1))}.text-red-400{--tw-text-opacity: 1;color:rgb(248 113 113 / var(--tw-text-opacity, 1))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255 / var(--tw-text-opacity, 1))}.text-yellow-400{--tw-text-opacity: 1;color:rgb(250 204 21 / var(--tw-text-opacity, 1))}.text-yellow-500{--tw-text-opacity: 1;color:rgb(234 179 8 / var(--tw-text-opacity, 1))}.underline{text-decoration-line:underline}.overline{text-decoration-line:overline}.no-underline{text-decoration-line:none}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.placeholder-gray-500::placeholder{--tw-placeholder-opacity: 1;color:rgb(107 114 128 / var(--tw-placeholder-opacity, 1))}.opacity-80{opacity:.8}.shadow{--tw-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}.shadow-xl{--tw-shadow: 0 20px 25px -5px rgb(0 0 0 / .1), 0 8px 10px -6px rgb(0 0 0 / .1);--tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}.outline{outline-style:solid}.ring{--tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow, 0 0 #0000)}.blur{--tw-blur: blur(8px);filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.grayscale{--tw-grayscale: grayscale(100%);filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.invert{--tw-invert: invert(100%);filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.sepia{--tw-sepia: sepia(100%);filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.transition{transition-property:color,background-color,border-color,text-decoration-color,fill,stroke,opacity,box-shadow,transform,filter,backdrop-filter;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-colors{transition-property:color,background-color,border-color,text-decoration-color,fill,stroke;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.transition-transform{transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}.\\[k\\:string\\]{k:string}.hover\\:bg-gray-100:hover{--tw-bg-opacity: 1;background-color:rgb(243 244 246 / var(--tw-bg-opacity, 1))}.hover\\:bg-gray-800:hover{--tw-bg-opacity: 1;background-color:rgb(31 41 55 / var(--tw-bg-opacity, 1))}.hover\\:bg-slate-700:hover{--tw-bg-opacity: 1;background-color:rgb(51 65 85 / var(--tw-bg-opacity, 1))}.hover\\:text-white:hover{--tw-text-opacity: 1;color:rgb(255 255 255 / var(--tw-text-opacity, 1))}.focus\\:border-transparent:focus{border-color:transparent}.focus\\:outline-none:focus{outline:2px solid transparent;outline-offset:2px}.focus\\:ring-2:focus{--tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow, 0 0 #0000)}.focus\\:ring-blue-500:focus{--tw-ring-opacity: 1;--tw-ring-color: rgb(59 130 246 / var(--tw-ring-opacity, 1))}.group:hover .group-hover\\:block{display:block}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDEBAR_DATA_SOURCE]
                }] }], propDecorators: { menus: [{
                type: Input
            }], config: [{
                type: Input
            }], user: [{
                type: Input
            }], logo: [{
                type: Input
            }], showSearch: [{
                type: Input
            }], showProfile: [{
                type: Input
            }], showNotifications: [{
                type: Input
            }], showMessages: [{
                type: Input
            }], menuItemClicked: [{
                type: Output
            }], sidebarToggled: [{
                type: Output
            }], logoutClicked: [{
                type: Output
            }], searchChanged: [{
                type: Output
            }], notificationClicked: [{
                type: Output
            }], messageClicked: [{
                type: Output
            }] } });

/*
 * Public API Surface of sidebar
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SIDEBAR_DATA_SOURCE, SidebarComponent };
//# sourceMappingURL=sidebar.mjs.map
