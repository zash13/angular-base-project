import * as i0 from '@angular/core';
import { OnInit, OnDestroy, EventEmitter, InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';

interface MenuItem {
    id: string;
    title: string;
    icon?: string;
    matIcon?: string;
    iconType?: 'string' | 'mat-icon' | 'font-awesome' | 'svg';
    type: 'link' | 'dropdown' | 'header' | 'divider';
    active?: boolean;
    badge?: {
        text: string;
        class: 'badge-danger' | 'badge-success' | 'badge-warning' | 'badge-info' | 'badge-primary';
    };
    submenus?: MenuItem[];
    routerLink?: string | any[];
    externalLink?: string;
    disabled?: boolean;
    permissions?: string[];
    order?: number;
}
interface SidebarConfig {
    width: number;
    collapsedWidth: number;
    position: 'left' | 'right';
    collapsed: boolean;
    backdrop: boolean;
    backdropOpacity: number;
    closeOnClickOutside: boolean;
    animate: boolean;
    animationDuration: number;
    theme: 'dark' | 'light' | 'auto';
    rtl: boolean;
    backgroundImage?: string;
}
interface UserProfile {
    name: string;
    role: string;
    status: 'online' | 'offline' | 'away' | 'busy';
    avatar: string;
    email?: string;
}
interface LogoConfig {
    text: string;
    url: string;
    icon?: string;
    image?: string;
    matIcon?: string;
    iconType?: 'string' | 'mat-icon' | 'image';
}
interface SidebarNotification {
    id: string | number;
    title: string;
    message: string;
    icon: string;
    matIcon?: string;
    iconType?: 'string' | 'mat-icon';
    iconColor: string;
    time: string;
    read: boolean;
    type: 'success' | 'info' | 'warning' | 'error';
}
interface SidebarMessage {
    id: string | number;
    sender: string;
    avatar: string;
    message: string;
    time: string;
    read: boolean;
}

interface SidebarDataSource {
    menus(): Observable<MenuItem[]>;
    notifications(): Observable<SidebarNotification[]>;
    messages(): Observable<SidebarMessage[]>;
    markNotificationAsRead(id: string): void;
    markMessageAsRead(id: string): void;
}

declare class SidebarComponent implements OnInit, OnDestroy {
    private _dataSource;
    private subscriptions;
    private dataSource;
    menus: MenuItem[];
    config: Partial<SidebarConfig>;
    user: UserProfile;
    logo: LogoConfig;
    showSearch: boolean;
    showProfile: boolean;
    showNotifications: boolean;
    showMessages: boolean;
    menuItemClicked: EventEmitter<MenuItem>;
    sidebarToggled: EventEmitter<boolean>;
    logoutClicked: EventEmitter<void>;
    searchChanged: EventEmitter<string>;
    notificationClicked: EventEmitter<SidebarNotification>;
    messageClicked: EventEmitter<SidebarMessage>;
    searchText: string;
    isMobile: boolean;
    notifications: SidebarNotification[];
    messages: SidebarMessage[];
    unreadNotificationsCount: number;
    unreadMessagesCount: number;
    constructor(_dataSource: SidebarDataSource);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private loadData;
    toggleSidebar(): void;
    onNotificationClick(notification: SidebarNotification): void;
    onMessageClick(message: SidebarMessage): void;
    onSearch(value: string): void;
    onLogout(): void;
    private updateUnreadCounts;
    private checkMobile;
    get sidebarWidth(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarComponent, "lib-sidebar", never, { "menus": { "alias": "menus"; "required": false; }; "config": { "alias": "config"; "required": false; }; "user": { "alias": "user"; "required": false; }; "logo": { "alias": "logo"; "required": false; }; "showSearch": { "alias": "showSearch"; "required": false; }; "showProfile": { "alias": "showProfile"; "required": false; }; "showNotifications": { "alias": "showNotifications"; "required": false; }; "showMessages": { "alias": "showMessages"; "required": false; }; }, { "menuItemClicked": "menuItemClicked"; "sidebarToggled": "sidebarToggled"; "logoutClicked": "logoutClicked"; "searchChanged": "searchChanged"; "notificationClicked": "notificationClicked"; "messageClicked": "messageClicked"; }, never, never, true, never>;
}

interface SidebarTokens {
}

declare const SIDEBAR_DATA_SOURCE: InjectionToken<SidebarDataSource>;

export { SIDEBAR_DATA_SOURCE, SidebarComponent };
export type { LogoConfig, MenuItem, SidebarConfig, SidebarDataSource, SidebarMessage, SidebarNotification, SidebarTokens, UserProfile };
