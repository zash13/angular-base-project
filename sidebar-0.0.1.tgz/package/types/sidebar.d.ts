import * as sidebar from 'sidebar';
import * as i0 from '@angular/core';
import { OnChanges, EventEmitter, SimpleChanges, InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';

declare class SidebarState {
    readonly collapsed: i0.WritableSignal<boolean>;
    readonly isMobile: i0.WritableSignal<boolean>;
    readonly searchText: i0.WritableSignal<string>;
    toggle(): void;
    setCollapsed(value: boolean): void;
    setMobile(value: boolean): void;
    setSearch(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarState, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SidebarState>;
}

interface SidebarTheme {
    background: string;
    surface: string;
    primary: string;
    text: string;
    textSecondary: string;
    border: string;
    hover: string;
    active: string;
    headerBackground?: string;
    headerText?: string;
    profileBackground?: string;
    searchBackground?: string;
    searchBorder?: string;
    success: string;
    warning: string;
    error: string;
    info: string;
    shadowColor: string;
    transitionDuration: string;
}
declare const DEFAULT_DARK_THEME: SidebarTheme;
declare const DEFAULT_LIGHT_THEME: SidebarTheme;
type SidebarThemePreset = 'dark' | 'light' | 'custom';
interface SidebarThemeConfig {
    preset?: SidebarThemePreset;
    customTheme?: Partial<SidebarTheme>;
    darkMode?: boolean;
}

interface MenuItem {
    id: string;
    title?: string;
    icon?: string;
    iconType?: 'string' | 'mat-icon' | 'font-awesome' | 'svg';
    type: 'link' | 'dropdown' | 'header' | 'divider';
    active?: boolean;
    badge?: {
        text: string;
        class: 'badge-danger' | 'badge-success' | 'badge-warning' | 'badge-info' | 'badge-primary';
    };
    submenus?: MenuItem[];
    routerLink?: string | any[];
    externalLink?: string;
    disabled?: boolean;
    permissions?: string[];
    order?: number;
}
interface SidebarConfig {
    width: number;
    collapsedWidth: number;
    position: 'left' | 'right';
    collapsed: boolean;
    backdrop: boolean;
    backdropOpacity: number;
    closeOnClickOutside: boolean;
    animate: boolean;
    animationDuration: number;
    theme?: 'dark' | 'light' | 'auto';
    rtl: boolean;
    backgroundImage?: string;
    footerCollapsedMode?: 'all' | 'single' | 'none';
    collapsedFooterButton?: 'notifications' | 'messages' | 'settings' | 'logout';
}
interface LogoConfig {
    text: string;
    url: string;
    icon?: string;
    image?: string;
    iconType?: 'string' | 'mat-icon' | 'image';
    collapsedIcon?: string;
    collapsedImage?: string;
}
interface UserProfile {
    name: string;
    role: string;
    status: 'online' | 'offline' | 'away' | 'busy';
    avatar: string;
    email?: string;
}
interface SidebarNotification {
    id: string | number;
    title: string;
    message: string;
    icon: string;
    matIcon?: string;
    iconType?: 'string' | 'mat-icon';
    iconColor: string;
    time: string;
    read: boolean;
    type?: 'info' | 'success' | 'warning' | 'error' | 'danger' | 'info-alt';
}
interface SidebarMessage {
    id: string | number;
    sender: string;
    avatar: string;
    message: string;
    time: string;
    read: boolean;
}

interface SidebarConfigModel {
    layout?: SidebarLayoutOptions;
    features?: SidebarFeatureOptions;
    branding?: SidebarBranding;
    user?: UserProfile;
    theme?: SidebarThemeOptions;
}
interface SidebarThemeOptions {
    mode?: 'light' | 'dark' | 'auto';
    custom?: Partial<SidebarTheme>;
}
interface SidebarBranding {
    logo?: LogoConfig;
}
interface SidebarFeatureOptions {
    search?: boolean;
    profile?: boolean;
    notifications?: boolean;
    messages?: boolean;
    footerMode?: 'all' | 'single' | 'none';
    collapsedFooterButton?: 'notifications' | 'messages' | 'settings' | 'logout';
    toggleButton?: boolean;
}
interface SidebarLayoutOptions {
    width?: number;
    collapsedWidth?: number;
    position?: 'left' | 'right';
    collapsed?: boolean;
    rtl?: boolean;
    backdrop?: boolean;
}

declare class SidebarFacade {
    private globalConfig;
    private dataSource;
    private overrides;
    private menus;
    private notifications;
    private messages;
    constructor();
    setOverrides(config: Partial<SidebarConfigModel>): void;
    readonly config: i0.Signal<SidebarConfigModel>;
    readonly data: i0.Signal<{
        menus: MenuItem[];
        notifications: SidebarNotification[];
        messages: SidebarMessage[];
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SidebarFacade>;
}

declare class SidebarThemeService {
    private facade;
    constructor(facade: SidebarFacade);
    readonly theme: i0.Signal<SidebarTheme>;
    readonly cssVariables: i0.Signal<{
        '--sidebar-background': string;
        '--sidebar-surface': string;
        '--sidebar-primary': string;
        '--sidebar-text': string;
        '--sidebar-border': string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SidebarThemeService>;
}

declare class SidebarComponent implements OnChanges {
    state: SidebarState;
    facade: SidebarFacade;
    themeService: SidebarThemeService;
    overrides?: Partial<SidebarConfigModel>;
    collapsed?: boolean;
    menuItemClicked: EventEmitter<any>;
    toggleSidebar: EventEmitter<void>;
    logoutClicked: EventEmitter<void>;
    searchChanged: EventEmitter<string>;
    notificationClicked: EventEmitter<any>;
    messageClicked: EventEmitter<any>;
    sidebarToggleRequested: EventEmitter<void>;
    collapsedChange: EventEmitter<boolean>;
    toggle(): void;
    private _previousCollapsed;
    constructor(state: SidebarState, facade: SidebarFacade, themeService: SidebarThemeService);
    ngOnChanges(changes: SimpleChanges): void;
    get config(): SidebarConfigModel;
    get layout(): sidebar.SidebarLayoutOptions | undefined;
    get features(): sidebar.SidebarFeatureOptions | undefined;
    get user(): sidebar.UserProfile | undefined;
    get menus(): sidebar.MenuItem[];
    get notifications(): sidebar.SidebarNotification[];
    get messages(): sidebar.SidebarMessage[];
    get unreadNotificationsCount(): number;
    get unreadMessagesCount(): number;
    get currentTheme(): sidebar.SidebarTheme;
    getThemeCssVariables(): {
        '--sidebar-background': string;
        '--sidebar-surface': string;
        '--sidebar-primary': string;
        '--sidebar-text': string;
        '--sidebar-border': string;
    };
    onSidebarContentClick(): void;
    requestToggle(): void;
    onSearch(value: string): void;
    onLogout(): void;
    get isMobile(): boolean;
    get searchText(): string;
    get showProfile(): boolean;
    get showSearch(): boolean;
    get showToggleButton(): boolean;
    get isRtl(): boolean;
    getFooterConfig(): {
        collapsed: boolean;
        footerCollapsedMode: "all" | "single" | "none";
        collapsedFooterButton: "notifications" | "messages" | "settings" | "logout";
        rtl: boolean;
        position: "left" | "right";
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarComponent, "lib-sidebar", never, { "overrides": { "alias": "overrides"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; }, { "menuItemClicked": "menuItemClicked"; "toggleSidebar": "toggleSidebar"; "logoutClicked": "logoutClicked"; "searchChanged": "searchChanged"; "notificationClicked": "notificationClicked"; "messageClicked": "messageClicked"; "sidebarToggleRequested": "sidebarToggleRequested"; "collapsedChange": "collapsedChange"; }, never, never, true, never>;
}

declare const SIDEBAR_DEFAULT_CONFIG: SidebarConfigModel;

interface SidebarDataSource {
    menus(): Observable<MenuItem[]>;
    notifications(): Observable<SidebarNotification[]>;
    messages(): Observable<SidebarMessage[]>;
}

declare const SIDEBAR_CONFIG: InjectionToken<Partial<SidebarConfigModel>>;
declare const SIDEBAR_DATA_SOURCE: InjectionToken<SidebarDataSource>;

export { DEFAULT_DARK_THEME, DEFAULT_LIGHT_THEME, SIDEBAR_CONFIG, SIDEBAR_DATA_SOURCE, SIDEBAR_DEFAULT_CONFIG, SidebarComponent };
export type { LogoConfig, MenuItem, SidebarBranding, SidebarConfig, SidebarConfigModel, SidebarDataSource, SidebarFeatureOptions, SidebarLayoutOptions, SidebarMessage, SidebarNotification, SidebarTheme, SidebarThemeConfig, SidebarThemeOptions, SidebarThemePreset, UserProfile };
